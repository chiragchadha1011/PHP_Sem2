<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About Page</title>
    <meta name="description" content="About page">
    <meta name="robots" content="noindex, nofollow">
    <!-- add fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,400;0,700;1,400&family=Poppins:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
    <!-- add Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
    <!-- add our custom CSS -->
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
    <?php
    include 'header.php';//Global header
    ?>
    <main>
      <section class="masthead1">
        <div class="col-12">
          <h1> About The Creative Blog !!!! </h1>
        </div>
      </section>
      <div class="a1">

</div>
    
<section class="a">
<div class="mb-4">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <p>
                          A blog is an online platform where individuals or organizations share their thoughts, opinions, information, or experiences through written posts. Typically organized in reverse chronological order, blogs cover a wide range of topics, such as personal experiences, hobbies, travel, technology, fashion, health, and more. Bloggers use text, images, and sometimes videos to engage and connect with their audience. Blogs serve as a means of communication, allowing content creators to express themselves, provide valuable insights, educate readers, and initiate discussions. Readers can interact with the content through comments, likes, and shares, fostering a sense of community around shared interests. Blogs have become an integral part of the internet, offering diverse perspectives and information to a global audience.</p>
                        <img src="https://firstsiteguide.com/wp-content/uploads/2018/04/What-is-a-Blog-2.png" alt="Image1" id="p1">
                        <p>Blogging has evolved into a powerful medium that transcends personal expression. Beyond individual musings, it has become a potent tool for various purposes. Businesses leverage blogs to showcase expertise, engage with customers, and enhance their online presence. Educational institutions utilize blogs to share knowledge, updates, and resources with students and the wider community. Additionally, blogs play a pivotal role in journalism, enabling independent voices to report and analyze news, often offering alternative viewpoints. Moreover, blogs are a driving force in the world of content marketing, fostering connections between brands and consumers. The versatility of blogs allows creators to experiment with formats, from long-form articles to concise microblogs, fostering creativity and adaptation to changing online trends.</p>
                        <img src="https://i.pinimg.com/originals/0e/c6/a1/0ec6a1e61fabec794d7de8d2f871888b.png" alt="Image2" id="p2">
                        <p>Blogging's evolutionary journey began in the late 1990s as rudimentary digital diaries, where individuals shared personal reflections and anecdotes. With the advent of user-friendly platforms like Blogger and WordPress in the early 2000s, blogging gained widespread accessibility, fostering the creation of diverse niche blogs spanning topics from technology to lifestyle. The integration of social media in the mid-2000s revolutionized blogging by enabling seamless content sharing and engagement, propelling it into a realm of broader influence. As businesses recognized its potential, blogging emerged as a fundamental content marketing tool, allowing brands to connect authentically with audiences. Concurrently, bloggers entered the journalistic arena, offering unique perspectives and breaking news stories. This dynamic evolution continues with the integration of multimedia elements, such as videos and podcasts, further enriching the blogging experience. Today, blogging remains a resilient and multifaceted platform, encompassing personal expression, journalism, marketing, and community building, all contributing to its enduring relevance in the dynamic digital landscape.</p>
<img src="https://media.istockphoto.com/id/496848472/vector/blog-blogging-and-blogglers-theme.jpg?s=612x612&w=0&k=20&c=mSpcEVoA-YeViMFD--ozz_CyP1UXnEgw89MpU8bwd9s=" alt="Image3" id="p3">
                    </div>
                </div>
            </div>
</div>   
    </section>
     
     <?php
    include 'footer.php';//Global header
    ?>
    </main>

  </body>
</html>