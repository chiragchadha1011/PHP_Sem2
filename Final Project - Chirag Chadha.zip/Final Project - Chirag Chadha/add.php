<?php

include('database.php');

if(isset($_POST['submit'])){
    $fname = $_POST['user_first_name'];
    $lname = $_POST['user_last_name'];
    $gender = $_POST['user_gender'];
    $email = $_POST['user_email'];
    $phoneno = $_POST['user_phone'];
    
    

    $msg = "";
    

    $insert_data = "INSERT INTO blogUserData(fname, lname, gender, email, phoneno) VALUES ('$fname','$lname','$gender','$email','$phoneno,NOW())";
    $run_data = mysqli_query($con,$insert_data);

    if($run_data){
          $added = true;
    }else{
        echo "Data not inserted";
    }

}

?>

