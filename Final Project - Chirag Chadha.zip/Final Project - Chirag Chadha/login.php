<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: index.php");
  exit;
}
 
// Include database file
require_once "database.php";
 

$username = $password = "";
$username_err = $password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validations
    if(empty($username_err) && empty($password_err)){
       
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($con, $sql)){
            
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
          
            $param_username = $username;
            
            if(mysqli_stmt_execute($stmt)){
                
                mysqli_stmt_store_result($stmt);
                
                
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                 
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            
                            session_start();
                            
                            // Store data in  variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            // Redirect user to welcome page
                            header("location: index.php");
                        } else{
                            
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                    $username_err = "No account found with that username.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($con);
}
?>




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link href="./css/style.css" rel="stylesheet" >
    <title>Login Page</title>
  </head>
  <body>
   <!-- Responsive navbar-->
   <?php
    include 'header.php';//Global header
    ?>
    <section class="masthead">
		<div>
			<h1> THE TORONTO BLOG ! </h1>
		</div>
	</section>
<br><br>
     
        <div class="container">
            <div class="row">
               
                <div class="col-lg-8">
                   
                    <div class="card text-warning bg-dark mb-3">
                        <a href="#!"><img class="card-img-top" src="https://cdn.britannica.com/93/94493-050-35524FED/Toronto.jpg" alt="Toronto image" /></a>
                        <div class="card-body">
                            <div class="small text-muted text-warning">July 25, 2020</div>
                            <h2 class="card-title">TORONTO</h2>
                            <p class="card-text">Nestled along the shores of Lake Ontario, Toronto stands as a captivating blend of cultures, creativity, and cosmopolitan energy. Canada's largest city, Toronto embraces diversity with open arms, offering a rich tapestry of experiences for all who wander its streets. From the iconic CN Tower piercing the sky to the historic Distillery District's cobblestone charm, every corner reveals something unique. Immerse yourself in world-class museums like the Royal Ontario Museum and savor global flavors at St. Lawrence Market. Find respite amidst nature in High Park or feel the pulse of entertainment in the vibrant Entertainment District. Toronto's skyline reflects its modernity, while its neighborhoods echo its cultural fusion. This city beckons you to explore, to discover, and to be captivated by its ever-evolving urban allure.</p>
                            <a class="btn btn-warning" href="https://en.wikipedia.org/wiki/Toronto" target="_blank">Read more →</a>
                        </div>
                    </div>
                 
                    <div class="row">
                        <div class="col-lg-6">
                            <!-- Blog post-->
                            <div class="card text-warning bg-dark mb-3">
                                <a href="#!"><img class="card-img-top" src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0a/81/98/e4/edgewalk.jpg?w=1200&h=-1&s=1" alt="Edge Walk" /></a>
                                <div class="card-body">
                                    <div class="small text-muted text-warning">Aug 30, 2019</div>
                                    <h2 class="card-title h4">Things to do in Toronto</h2>
                                    <p class="card-text">Discover the vibrant tapestry of Toronto, where modern marvels and cultural treasures converge. Ascend the iconic CN Tower for panoramic cityscape views, or delve into history and heritage at the Royal Ontario Museum. Wander the enchanting Distillery Historic District's cobblestone streets, and seek solace on the Toronto Islands' tranquil shores. St. Lawrence Market beckons with a culinary symphony, while Ripley's Aquarium mesmerizes with aquatic wonders. Art aficionados will find solace in the Art Gallery of Ontario, while Kensington Market exudes eclectic charm. High Park offers a natural retreat, and the Entertainment District pulses with nightlife. Toronto invites you to explore its diverse tapestry, each thread weaving a unique and unforgettable urban experience.</p>
                                    <a class="btn btn-warning" href="https://www.getyourguide.com/-l177/?cmp=ga&cq_src=google_ads&cq_cmp=15511491065&cq_con=130891976077&cq_term=things%20to%20do%20in%20toronto&cq_med=&cq_plac=&cq_net=g&cq_pos=&cq_plt=gp&campaign_id=15511491065&adgroup_id=130891976077&target_id=aud-902501298926:kwd-2680987980&loc_physical_ms=9000801&match_type=e&ad_id=569326921880&keyword=things%20to%20do%20in%20toronto&ad_position=&feed_item_id=&placement=&device=c&partner_id=CD951&gclid=Cj0KCQjwrMKmBhCJARIsAHuEAPROPohJ6KN_hfyTG41TasnpTR0jh9EbZqsmqmsNNHyQZH1bY-ABXGUaAgNfEALw_wcB" target="_blank">Read more →</a>
                                </div>
                            </div>
                            <!-- Blog post-->
                            <div class="card text-warning bg-dark mb-3">
                                <a href="#!"><img class="card-img-top" src="https://www.kiwi.com/stories/wp-content/uploads/2017/10/shutterstock_540820594-1000x667.jpg" alt="Thrilling Toronto"></a>
                                <div class="card-body">
                                    <div class="small text-muted text-warning">October 11, 2021</div>
                                    <h2 class="card-title h4">A Thrill Seeker’s Guide to Toronto</h2>
                                    <p class="card-text">Embark on an adrenaline-charged adventure through Toronto, where thrill-seekers find their playground in every corner. Ascend the CN Tower for a heart-pounding EdgeWalk, daring you to walk on the edge of the world. Dive into the depths of Ripley's Aquarium, surrounded by mesmerizing marine life. Unleash your inner explorer at the Toronto Islands, kayaking or zip-lining amidst breathtaking views. Feel the rush of Toronto's vibrant Entertainment District, offering live shows and bustling nightlife. From high-flying exploits to aquatic escapades, Toronto ignites the spirit of the thrill-seeker at every turn.</p>
                                    <a class="btn btn-warning" href="https://www.tripadvisor.ca/Attractions-g155019-Activities-zft11312-Toronto_Ontario.html" target="_blank">Read more →</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <!-- Blog post-->
                            <div class="card text-warning bg-dark mb-3">
                                <a href="#!"><img class="card-img-top" src="https://a.cdn-hotels.com/gdcs/production24/d1597/4f3f77cf-bdca-4ec3-af5d-ea923d74f672.jpg?impolicy=fcrop&w=800&h=533&q=medium" alt="Food of Toronto" /></a>
                                <div class="card-body">
                                    <div class="small text-muted text-warning">December 29, 2021</div>
                                    <h2 class="card-title h4">Taste Toronto: A Culinary Adventure</h2>
                                    <p class="card-text">Toronto's culinary scene is a tantalizing tapestry of global flavors. From St. Lawrence Market's fresh delights to diverse street food in Kensington Market, the city's palate is an adventure. Discover authentic dim sum in Chinatown, indulge in Little Italy's pasta, and savor fusion cuisine across neighborhoods. Embrace artisanal cafes, iconic sandwiches, and local brews. Toronto's food culture invites you to taste the world in every bite. </p>
                                    <a class="btn btn-warning" href="https://ca.hotels.com/go/canada/ca-best-local-dishes-from-toronto" target="_blank">Read more →</a>
                                </div>
                            </div>
                            <!-- Blog post-->
                            <div class="card text-warning bg-dark mb-3">
                                <a href="#!"><img class="card-img-top" src="https://a.cdn-hotels.com/gdcs/production84/d1205/d3d70d60-3c22-4e3c-bb3d-6435950e2f8a.jpg" alt="Shop at Toronto" /></a>
                                <div class="card-body">
                                    <div class="small text-muted text-warning">July 2, 2021</div>
                                    <h2 class="card-title h4">Retail Paradise: Shopping in Toronto</h2>
                                    <p class="card-text">Indulge in a shopping paradise in Toronto, where a world of retail awaits. From luxury boutiques in Yorkville to eclectic finds in Kensington Market, the city caters to all styles. Explore the iconic Eaton Centre for global brands and chic fashion, or dive into the Distillery District's artisanal boutiques. Unearth vintage treasures, designer labels, and unique souvenirs as Toronto invites you to shop 'til you drop.</p>
                                    <a class="btn btn-warning" href="https://www.tripsavvy.com/great-toronto-shopping-spots-1482044" target="_blank">Read more →</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
             
                <div class="col-lg-4" >
                  
                    <div class="card text-warning bg-dark mb-3" >
                        <div class="card-header">Discover</div>
                        <div class="card-body">
                            <div class="input-group">
                                <input class="form-control" type="text" placeholder="Discover anything.." aria-label="Discover anything.." aria-describedby="button-search" />
                                <a href="https://www.wikipedia.org/"><button class="btn btn-warning" id="button-search" type="button">LESSGO</button></a>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="card text-warning bg-dark mb-3">
                        <div class="card-header">Different Blogs</div>
                        <div class="card-body text-warning">
                            <div class="row">
                                <div class="col-sm-6 text-warning">
                                    <ul class="list-warning mb-0">
                                        <li><a href="#!">Football</a></li>
                                        <li><a href="#!">Cities of England</a></li>
                                        <li><a href="#!">Indian Culture</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-6">
                                    <ul class="list-warning mb-0 text-warning">
                                        <li><a href="#!">Marvel</a></li>
                                        <li><a href="#!">Artificial Intelligence</a></li>
                                        <li><a href="#!">Explore Italy</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    <div class="card text-warning bg-dark mb-3">
                        <div class="card-header">Are you already a User?</div>
                        <div class="card-body">If you are an existing user, please login below.</div>
                    </div>
                    <div class="card mb-4">

    <div class="card text-warning bg-dark mb-3" style="width: 22.3rem;" id="log"><br>
  <img class="card-img-top mx-auto" src="./images/Loginn.jpeg" style="width: 60%; " alt="Login">
  <div class="card-body">

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                <label>Username</label>
                <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            
 <button type="submit" class="btn btn-warning"><i class="fa fa-lock">&nbsp;</i> Login</button> &nbsp; &nbsp; 
<button type="reset" class="btn btn-warning "><i class="fa fa-repeat">&nbsp;</i> Reset</button>
        
         
        </form>
  </div>

</div>
                    </div>
                    <div class="card text-warning bg-black mb-3">
                        <div class="card-header">Do you not yet have an account?</div>
                        
      <a href="register.php"class="btn btn-warning my-2 my-sm-0" type="submit">Create Account</a>
    
                    </div>
                </div>
            </div>
        </div>
     
       
        


    <?php
     include 'footer.php';//Global Footer
     ?>
  
   <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>