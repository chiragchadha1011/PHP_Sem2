<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
// database connection
include('database.php');

$added = false;

//Add new user

if(isset($_POST['submit'])){
    $fname = $_POST['user_first_name'];
    $lname = $_POST['user_last_name'];
    $gender = $_POST['user_gender'];
    $email = $_POST['user_email'];
    $phoneno = $_POST['user_phone'];
    
    $insert_data = "INSERT INTO blogUserData(fname, lname, gender, email, phoneno) VALUES ('$fname','$lname','$gender','$email','$phoneno')";
    $run_data = mysqli_query($con,$insert_data);

    if($run_data){
          $added = true;
    }else{
        echo "Unable to insert data";
    }

}

?>






<!DOCTYPE html>
<html>
<head>
    <title>Student Crud Operation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    
</head>
<body>

    
    <div class="container">


<!--  alert notification  -->
<?php
    if($added){
        echo "
            <div class='btn-success' style='padding: 15px; text-align:center;'>
                Your Student Data has been Successfully Added.
            </div><br>
        ";
    }

?>




    <a href="logout.php" class="btn btn-danger"><i class="fa fa-lock"></i> Logout</a>
    <button class="btn btn-info" type="button" data-toggle="modal" data-target="#myModal">
  <i class="fa fa-plus"></i> Add New User
  </button>
 
  <hr>
        <table class="table  table-bordered table-hover table-dark table-striped" id="myTable">
        <thead>
            <tr>
               <th class="text-center" scope="col">S.No</th>
                <th class="text-center" scope="col">Name</th>
                <th class="text-center" scope="col">Phone</th>
                <th class="text-center" scope="col">Email</th>
                <th class="text-center" scope="col">Gender</th>
                <th class="text-center" scope="col">Update</th>
                <th class="text-center" scope="col">Delete</th>
            </tr>
        </thead>
            <?php

            $get_data = "SELECT * FROM blogUserData order by 1 desc";
            $run_data = mysqli_query($con,$get_data);
            $i = 0;
            while($row = mysqli_fetch_array($run_data))
            {
                $sl = ++$i;
                $id = $row['id'];
                $fname = $row['fname'];
                $lname = $row['lname'];
                $phoneno = $row['phoneno'];
                $email=$row['email'];
                $gender=$row['gender'];
               


                echo "

                <tr>
                <td class='text-center'>$sl</td>
                <td class='text-left'>$fname   $lname</td>
                <td class='text-left'>$phoneno</td>
                <td class='text-left'>$email</td>
                <td class='text-left'>$gender</td>
            
              
                <td class='text-center'>
                    <span>
                    <a href='#' class='btn btn-warning mr-2' data-toggle='modal' data-target='#edit$id' title='Edit'><i class='fa fa-pencil text-white'></i></a>

                         
                        
                    </span>
                    
                </td>
                <td class='text-center'>
                    <span>
                    
                        <a href='#' class='btn btn-danger mr-2' title='Delete'>
                             <i class='fa fa-trash text-white' data-toggle='modal' data-target='#$id'  aria-hidden='true'></i>
                        </a>
                    </span>
                    
                </td>
            </tr> ";
            }

            ?>
            </table>
        </div>

 

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

   
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <center><img src="http://www.clker.com/cliparts/q/g/0/H/P/O/add-user-button-hi.png" width="300px" height="80px" alt=""></center>
    
      </div>
      <div class="modal-body">
        <form method="POST" enctype="multipart/form-data">
            
           
<div class="form-row">
<div class="form-group col-md-6">
<label for="firstname">First Name</label>
<input type="text" class="form-control" name="user_first_name" placeholder="Enter First Name">
</div>
<div class="form-group col-md-6">
<label for="lastname">Last Name</label>
<input type="text" class="form-control" name="user_last_name" placeholder="Enter Last Name">
</div>
</div>
<div class="form-row">
<div class="form-group col-md-6">
<label for="inputPassword4">Mobile No.</label>
<input type="phone" class="form-control" name="user_phone" placeholder="Enter 10-digit Mobile no." maxlength="10" required>
</div>
<div class="form-group col-md-6">
<label for="email">Email Id</label>
<input type="email" class="form-control" name="user_email" placeholder="Enter Email id">
</div>
</div>

<div class="form-row">
<div class="form-group col-md-6">
<label for="inputState">Gender</label>
<select id="inputState" name="user_gender" class="form-control">
  <option selected>Choose...</option>
  <option>Male</option>
  <option>Female</option>
  <option>Other</option>
</select>
</div>

</div>



            
             <input type="submit" name="submit" class="btn btn-info btn-large" value="Submit">
            
            
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!-- Delte -->
<?php

$get_data = "SELECT * FROM blogUserData";
$run_data = mysqli_query($con,$get_data);

while($row = mysqli_fetch_array($run_data))
{
    $id = $row['id'];
    echo "

<div id='$id' class='modal fade' role='dialog'>
  <div class='modal-dialog'>

    <!-- Modal content-->
    <div class='modal-content'>
      <div class='modal-header'>
        <button type='button' class='close' data-dismiss='modal'>&times;</button>
        <h4 class='modal-title text-center'>Are you want to sure??</h4>
      </div>
      <div class='modal-body'>
        <a href='delete.php?id=$id' class='btn btn-danger' style='margin-left:250px'>Delete</a>
      </div>
      
    </div>

  </div>
</div>

    ";
    
}

?>






<!-- edit -->

<?php

$get_data = "SELECT * FROM blogUserData";
$run_data = mysqli_query($con,$get_data);

while($row = mysqli_fetch_array($run_data))
{
    $id = $row['id'];
    $name = $row['fname'];
    $name2 = $row['lname'];
    $gender = $row['gender'];
    $email = $row['email'];
    $phone = $row['phoneno'];
  
    echo "

<div id='edit$id' class='modal fade' role='dialog'>
  <div class='modal-dialog'>

    <!-- Modal content-->
    <div class='modal-content'>
      <div class='modal-header'>
             <button type='button' class='close' data-dismiss='modal'>&times;</button>
             <center><img src='http://clipground.com/images/edit-clipart-3.jpg' width='300px' height='80px'></center>
      </div>

      <div class='modal-body'>
        <form action='edit.php?id=$id' method='post' enctype='multipart/form-data'>

         <div class='form-row'>
        <div class='form-group col-md-6'>
        <label for='firstname'>First Name</label>
        <input type='text' class='form-control' name='user_first_name' placeholder='Enter First Name' value='$name'>
        </div>
        <div class='form-group col-md-6'>
        <label for='lastname'>Last Name</label>
        <input type='text' class='form-control' name='user_last_name' placeholder='Enter Last Name' value='$name2'>
        </div>
        </div>
		<div class='form-row'>
        <div class='form-group col-md-6'>
        <label for='inputPassword4'>Mobile No.</label>
        <input type='phone' class='form-control' name='user_phone' placeholder='Enter 10-digit Mobile no.' maxlength='10' value='$phone' required>
        </div>
		<div class='form-group col-md-6'>
        <label for='email'>Email Id</label>
        <input type='email' class='form-control' name='user_email' placeholder='Enter Email id' value='$email'>
        </div>

        </div>
            
        <div class='form-row'>
        <div class='form-group col-md-6'>
        <label for='inputState'>Gender</label>
        <select id='inputState' name='user_gender' class='form-control' value='$gender'>
          <option selected>$gender</option>
          <option>Male</option>
          <option>Female</option>
          <option>Other</option>
        </select>
        </div>
        </div>
                    
             <div class='modal-footer'>
             <input type='submit' name='submit' class='btn btn-info btn-large' value='Submit'>
             <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
         </div>

        </form>
      </div>

    </div>

  </div>
</div>

    ";
}

?>
 

<script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  <script>
    $(document).ready(function () {
      $('#myTable').DataTable();

    });
  </script>

</body>
</html>


