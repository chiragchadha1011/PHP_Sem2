<?php
include('database.php');

$id = $_GET['id'];

if(isset($_POST['submit']))
{
    $fname = $_POST['user_first_name'];
    $lname = $_POST['user_last_name'];
    $gender = $_POST['user_gender'];
    $email = $_POST['user_email'];
    $phoneno = $_POST['user_phone'];
    
    $msg = "";
   

    $update = "UPDATE blogUserData SET  fname = '$fname', lname = '$lname', gender = '$gender', email = '$email', phoneno = '$phoneno' WHERE id=$id ";
    $run_update = mysqli_query($con,$update);

    if($run_update){
        header('location:index.php');
    }else{
        echo "Data not updated";
    }
}

?>

