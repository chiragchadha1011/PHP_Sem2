<?php

define('DB_SERVER', '172.31.22.43');
define('DB_USERNAME', 'Chirag200515506');
define('DB_PASSWORD', 'E3j6qi3Jet');
define('DB_NAME', 'Chirag200515506');
 
/* Attempt to connect to MySQL database */
$con = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>