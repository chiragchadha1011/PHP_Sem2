
CREATE TABLE blogUserData (
  id int(100) NOT NULL ,
  fname varchar(100) NOT NULL,
  lname varchar(100) NOT NULL,
  gender varchar(100) NOT NULL,
  email varchar(100) NOT NULL,
  phoneno varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO blogUserData (id,fname,lname, gender, email, phoneno) 
VALUES
('123', 'John', 'Doe', 'Male', 'user123@example.com', '1234567890'),
('456', 'Jane', 'Smith', 'Female', 'user456@example.com', '9876543210'),
('789', 'Michael', 'Johnson', 'Male', 'user789@example.com', '4567891230'),
('234', 'Emily', 'Williams', 'Female', 'user234@example.com', '7890123456'),
('567', 'David', 'Brown', 'Male', 'user567@example.com', '2345678901');




CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(7, 'ak', '$2y$10$fVuMuB.Z05qESvo5Wx2MA.tREMC1HgZpaxfaDVGl3hTUignCImAdK', '2022-12-06 23:32:17'),
(8, 'aryan', '$2y$10$IRuvT7U9uvdsTHJOPQ0w7..urG1Bs0PMzP98XUD103A9ltE0LcBG6', '2022-12-07 19:55:34');


ALTER TABLE `blogUserData`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);


ALTER TABLE `blogUserData`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;


ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;
