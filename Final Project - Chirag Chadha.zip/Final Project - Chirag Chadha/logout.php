<?php
session_start();// Initialize the session
session_unset();                 
session_destroy();// Destroy the session.
header("location: login.php");// Redirect to login page
exit;
?>