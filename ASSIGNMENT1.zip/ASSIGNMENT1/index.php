<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pizza Form</title>
    <meta name="description" content="Assignment 1.">
    <meta name="robots" content="noindex, nofollow">

    <!-- add our custom CSS -->
    <link rel="stylesheet" href="./css/style.css">

     <!-- add Bootstrap -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>

</head>
<body>
<header>
    <!-- navigation using bootstrap -->
      <nav class="navbar navbar-dark bg-danger fixed-top">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <img src="./img/The_Pizza_Company_Logo.svg" alt="Pizza logo">
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
            <div class="offcanvas-header">
              <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menu</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
              <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item"><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php">Coupouns</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php">About us</a></li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </header>

    <section class="masthead row">
        <div class="col-12">
          <h1>! The Pizza Company Welcomes you!</h1>
          <h2>---Pizza is always the answer.---</h2>
        </div>
      </section>


        <div class="form-container">

        <h3 class="txt">!Order Now!</h3>
        <p class="txt">Place your customized order below</p>

        <form method="POST" action=view.php>
        <!-- first name -->
        <label for="fname" class="form-label">First Name:</label>
          <p><input type="text" id="fname" name="fname" placeholder="First Name" class="form-control" required></p>
          <!-- last name -->
          <label for="lname" class="form-label">Last Name:</label>
          <p><input type="text" name="lname" id="lname" placeholder="Last Name" class="form-control" required></p>
         <!-- email -->
          <label for="email" class="form-label">Email Address:</label>
          <p><input type="email" name="email" id="email" placeholder="Email" class="form-control" required></p>
          <!-- Phone number -->
          <label for="phonenum" class="form-label">Phone Number:</label>
         <p><input type="tel" name="phonenum" id="phonenum" placeholder="Phone Number" class="form-control" required></p>
         <!-- password -->
         <label for="pass" class="form-label">Password:</label>
          <p><input type="password" name="pass" id="pass" placeholder="Password" class="form-control" required></p>
          <!-- radio button size -->
          <p>Size:</p>
         <input type="radio" name="answer" id="small" value="Small" class="form-check-input" >
         <label for="small" class="form-check-label">Small</label>
         <input type="radio" name="answer" id="medium" value="Medium" class="form-check-input">
          <label for="medium" class="form-check-label">Medium</label>
        <input type="radio" name="answer" id="large" value="Large" class="form-check-input">
          <label for="large" class="form-check-label">Large</label>
       <input type="radio" name="answer" id="xlarge" value="Extra Large" class="form-check-input">
          <label for="xlarge" class="form-check-label">Extra Large</label>
          <br>
          <!-- Base using select -->
          <label class="form-label">Base Crust: </label>
          <select name="baseCrust" class="form-select" aria-label="Default select example">
            <option selected>Choose your Crust</option>
            <option value="Original">Original</option>
            <option value="Thin Crust">Thin Crust</option>
            <option value="Pan base">Pan base</option>
            <option value="Cheese Burst">Cheese Burst</option>
        </select>
        <br>
        <!-- toppings using checkbox -->
          <p>Preferred toppings:</p>
          <input type="checkbox" id="choice1" name="toppings[]" value=" Onion " class="form-check-input">
            <label for="choice1" class="form-check-label">Onion</label>
          <input type="checkbox" id="choice2" name="toppings[]" value=" Bell Pepper " class="form-check-input">
            <label for="choice2" class="form-check-label">Bell Pepper</label>
          <input type="checkbox" id="choice3" name="toppings[]" value=" Corns " class="form-check-input">
            <label for="choice3" class="form-check-label">Corns</label>
          <input type="checkbox" id="choice4" name="toppings[]" value=" Tomatoes " class="form-check-input">
            <label for="choice4" class="form-check-label">Tomatoes</label>
        <input type="checkbox" id="choice5" name="toppings[]" value=" Chicken " class="form-check-input">
            <label for="choice5" class="form-check-label">Chicken</label>
        <input type="checkbox" id="choice6" name="toppings[]" value=" Bacon " class="form-check-input">
            <label for="choice6" class="form-check-label">Bacon</label>
       <input type="checkbox" id="choice7" name="toppings[]" value=" Beef " class="form-check-input">
            <label for="choice7" class="form-check-label">Beef</label>
        <input type="checkbox" id="choice8" name="toppings[]" value=" Pepproni " class="form-check-input">
            <label for="choice8" class="form-check-label">Pepproni</label>
       <input type="checkbox" id="choice9" name="toppings[]" value=" Extra Cheese " class="form-check-input">
            <label for="choice9" class="form-check-label">Extra Cheese</label>
            <br>
            <!-- Textarea -->
            <div class="form-floating">
                <textarea class="form-control" placeholder="Specific Instructions" id="floatingTextarea" name="special"></textarea>
                <label for="floatingTextarea">Specific Instructions</label>
                </div>
            <br>
            <!-- Prefrence using radio button -->
            <label class="form-label">Prefered Way:</label>
            <input type="radio" name="choice" id="dine" value="Dine-In" class="form-check-input" >
           <label for="dine" class="form-check-label">Dine-In</label>
           <input type="radio" name="choice" id="take" value="Take-Away" class="form-check-input">
          <label for="take" class="form-check-label">Take-away</label>
          <input type="radio" name="choice" id="deliver" value="Delivery" class="form-check-input">
          <label for="deliver" class="form-check-label">Delivery</label>
          <br>
            <input class="btn btn-primary submit" type="submit" value="Submit">
            <input class="btn btn-dark reset" type="reset" value="Reset">


      </form>


    <a href="view.php">View</a>
</div>

    
    <?php
                      require_once('database.php');
                     if(isset($_POST) & !empty($_POST)){
                         $fname = $database->sanitize($_POST['fname']);
                         $lname = $database->sanitize($_POST['lname']);
                         $email = $database->sanitize($_POST['email']);
                         $phonenum = $database->sanitize($_POST['phonenum']);
                         $pass = $database->sanitize($_POST['pass']);
                         $baseCrust = $database->sanitize($_POST['baseCrust']);
                         $toppings = $database->sanitize($_POST['toppings']);
                         $special = $database->sanitize($_POST['special']);
                         $choice = $database->sanitize($_POST['choice']);

                         $res   = $database->create($fname, $lname, $email, $phonenum, $pass, $baseCrust, $toppings, $special, $choice);
                         
                     }
      ?>
      
      <div >
  <footer>
     <section>
        <div class="row d-flex justify-content-center">
          <div class="col-lg-8">
            <p>
            The contents of the Pizza Company Website are protected by copyright law and may not be reproduced, distributed, or transmitted in any form or by any means without the prior written permission of the copyright owner. Unauthorized copying, reproduction, or distribution of the materials contained herein is strictly prohibited and may result in severe civil and criminal penalties.
            </p>
          </div>
        </div>
      </section>
    <div class="text-center text-white p-3" >
      © 2022 Copyright:
      <a class="text-white" href="index.php">The Pizza Company</a>
    </div>
  </footer> 

</div>
</body>
</html>