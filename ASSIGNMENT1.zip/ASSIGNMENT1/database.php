<?php
 
  class Database{
    
    private $connection;
    function __construct(){
    
      $this->connect_db();
    }
  
    public function connect_db(){
      $this->connection = mysqli_connect('172.31.22.43', 'Chirag200515506', 'E3j6qi3Jet', 'Chirag200515506');
      if(mysqli_connect_error()){
        die("Database Connection Failed" . mysqli_connect_error() . mysqli_connect_error());
      }
    }
    public function create($fname, $lname, $email, $phonenum, $pass, $baseCrust, $toppings, $special, $choice){
      $sql = "INSERT INTO Customers (fname, lname, email, phonenum, pass, baseCrust, toppings, special, choice) VALUES ($fname, $lname, $email, $phonenum, $pass, $baseCrust, $toppings, $special, $choice)";
      $res = mysqli_query($this->connection, $sql);
      if($res){
	 		    return true;
		  }
      else{
			    return false;
		  }
    }
    public function read($id=null){
		    $sql = "SELECT * FROM Customers";
		    if($id){
          $sql .= " WHERE id=$id";
        }
 		    $res = mysqli_query($this->connection, $sql);
 		    return $res;
	  }
  
    public function sanitize($var){
      $return = mysqli_real_escape_string($this->connection, $var);
      return $return;
    }

  }
  $database = new Database();
?>
