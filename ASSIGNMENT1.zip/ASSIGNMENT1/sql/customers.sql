CREATE TABLE Customers (
  fname varchar(255) not null,
  lname varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  phonenum varchar(255) NOT NULL primary key (id),
  baseCrust varchar(255) NOT NULL,
  toppings varchar(255) NOT NULL,


);

INSERT into Customers (fname, lname, email, phonenum ,baseCrust, toppings)
VALUES();
