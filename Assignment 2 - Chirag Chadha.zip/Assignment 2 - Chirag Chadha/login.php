<?php
require_once "./database/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user["password"])) {
        session_start();
        $_SESSION["username"] = $username;
        header("Location: success.php");
        exit();
    } else {
        echo "Invalid username or password.";
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Assignment2</title>
    <meta name="description" content="This week we will look at how we can protect pages behind a level of authenication.">
    <meta name="robots" content="noindex, nofollow">
    <!-- add our fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
  	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&family=Roboto:ital,wght@0,400;0,500;0,700;1,400&display=swap" rel="stylesheet">
    <!-- add Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
    <!-- add our custom CSS -->
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
    <header>
      <nav class="navbar navbar-dark bg-primary">
        <div class="container-fluid" id="heading">
          <a class="navbar-brand" href="index.php">Assignment 2</a>
          <button class="navbar-toggler bg-dark" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon bg-dark"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item"><a class="nav-link active" aria-current="page" href="login.php">Home</a></li>
              <li class="nav-item"><a class="nav-link" href="#sign_in">Login</a></li>
              <li class="nav-item"><a class="nav-link" href="#sign_up">SignUp</a></li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    
    <section class="masthead">
		<div>
			<h1> Welcome to the Assignment 2! </h1>
		</div>
	</section>

    <section class="form-row row">
    
    <div class="col-sm-12 col-md-6 col-lg-6 bg-primary text-dark" id="sign_in">
        <h3>Already have an account, then sign in below!</h3>
        <form method="post" action="validate.php">
        	<p><input class="form-control" name="username" type="text" placeholder="Username" required /></p>
        	<p><input class="form-control" name="password" type="password" placeholder="Password" required /></p>
          <input class="btn btn-light" type="submit" value="Login" />
        </form>
      </div>

      <div class="col-sm-12 col-md-6 col-lg-6 bg-primary text-dark" id="sign_up">
    <h3>Don't have an account, then sign up below!</h3>
    <form method="post" action="saveuser.php">
        <p><input class="form-control" name="username" type="text" placeholder="Username" required/></p>
        <p><input class="form-control" name="password" type="password" placeholder="Password" required /></p>
        <p><input class="form-control" name="confirm" type="password" placeholder="Confirm Password" required /></p>
        <input class="btn btn-light" type="submit" name="submit" value="Register" />
    </form>
</div>


    </section>

</body>
</html>

