CREATE table login_details(
	id int(5) not null auto_increment primary key,
	username varchar (55),
	password VARCHAR(255) NOT NULL
);

select * from login_details;
